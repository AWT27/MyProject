<?php
session_start();
include 'db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SESSION["has_voted"]) {
    echo "<div class='alert alert-info text-center mt-5'>You have already voted. <a href='results.php'>View results</a></div>";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $candidate_id = $_POST["candidate_id"];
    $user_id = $_SESSION["user_id"];

    $stmt = $conn->prepare("UPDATE candidates SET votes = votes + 1 WHERE id = ?");
    $stmt->bind_param("i", $candidate_id);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE users SET has_voted = 1 WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $_SESSION["has_voted"] = 1;

    header("Location: results.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vote - Voting App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow border-0">
        <div class="card-body">
            <h3 class="card-title text-center mb-4">Cast Your Vote</h3>
            <form method="POST" class="text-center">
                <?php
                $result = $conn->query("SELECT * FROM candidates");
                while ($row = $result->fetch_assoc()): ?>
                    <div class="form-check mb-2 text-start mx-auto" style="max-width: 300px;">
                        <input class="form-check-input" type="radio" name="candidate_id" id="cand<?= $row['id'] ?>" value="<?= $row['id'] ?>" required>
                        <label class="form-check-label" for="cand<?= $row['id'] ?>">
                            <?= htmlspecialchars($row['name']) ?>
                        </label>
                    </div>
                <?php endwhile; ?>
                <button type="submit" class="btn btn-primary mt-3">Submit Vote</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
